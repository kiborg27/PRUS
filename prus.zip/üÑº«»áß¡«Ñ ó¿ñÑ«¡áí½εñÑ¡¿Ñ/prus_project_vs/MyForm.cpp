#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace prus;

[STAThread]
void main() {
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);
    prus::MyForm form;
    Application::Run(% form);
}