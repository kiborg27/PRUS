#pragma once
#include "auth.h"
#include "bdman.h"
#include "bdnsd.h"
#include <windows.h>
#include <fstream>


namespace prus {



	
	

	




	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	
	String^ kamera = ""; // ����� ������ �� ������ �������
	String^ mode = ""; // �������� ��� ������?
	int kamera_n = 0; // ���������� �������

	int sys = 0; // �������� �� �������? �������


	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::CheckBox^ checkBox1;
		   bool Up = false;




	public:

		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ ����ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ N1;
	private: System::Windows::Forms::ToolStripMenuItem^ N2;
	private: System::Windows::Forms::ToolStripMenuItem^ N12;

	private: System::Windows::Forms::ToolStripMenuItem^ N13;

		   


	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::ToolStripMenuItem^ N3;

	private:






	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::DataGridView^ dataGridView1;



	private: System::Windows::Forms::Label^ label5;



	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column2;
	private: System::Windows::Forms::Timer^ timer1;
	private: System::ComponentModel::IContainer^ components;




















	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->����ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->N1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->N2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->N3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->N12 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->N13 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->menuStrip1->SuspendLayout();
			this->panel1->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->����ToolStripMenuItem,
					this->N12, this->N13
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(12, 3, 0, 3);
			this->menuStrip1->Size = System::Drawing::Size(1115, 30);
			this->menuStrip1->TabIndex = 2;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// ����ToolStripMenuItem
			// 
			this->����ToolStripMenuItem->BackColor = System::Drawing::SystemColors::ControlLight;
			this->����ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->N1,
					this->N2, this->N3
			});
			this->����ToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->����ToolStripMenuItem->Name = L"����ToolStripMenuItem";
			this->����ToolStripMenuItem->Size = System::Drawing::Size(65, 24);
			this->����ToolStripMenuItem->Text = L"����";
			// 
			// N1
			// 
			this->N1->Enabled = false;
			this->N1->Name = L"N1";
			this->N1->Size = System::Drawing::Size(260, 26);
			this->N1->Text = L"��������� ������� ����";
			this->N1->Click += gcnew System::EventHandler(this, &MyForm::N1_Click);
			// 
			// N2
			// 
			this->N2->Name = L"N2";
			this->N2->Size = System::Drawing::Size(260, 26);
			this->N2->Text = L"�������� � ��";
			this->N2->Click += gcnew System::EventHandler(this, &MyForm::N2_Click);
			// 
			// N3
			// 
			this->N3->Name = L"N3";
			this->N3->Size = System::Drawing::Size(260, 26);
			this->N3->Text = L"��� �� ����������";
			this->N3->Click += gcnew System::EventHandler(this, &MyForm::N3_Click);
			// 
			// N12
			// 
			this->N12->BackColor = System::Drawing::SystemColors::ControlLight;
			this->N12->Name = L"N12";
			this->N12->Size = System::Drawing::Size(81, 24);
			this->N12->Text = L"�������";
			this->N12->Click += gcnew System::EventHandler(this, &MyForm::N12ToolStripMenuItem_Click);
			// 
			// N13
			// 
			this->N13->Name = L"N13";
			this->N13->Size = System::Drawing::Size(67, 24);
			this->N13->Text = L"�����";
			this->N13->Click += gcnew System::EventHandler(this, &MyForm::N13ToolStripMenuItem_Click);
			// 
			// button1
			// 
			this->button1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->button1->Location = System::Drawing::Point(7, 39);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(155, 47);
			this->button1->TabIndex = 3;
			this->button1->Text = L"�������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->button2->Location = System::Drawing::Point(7, 92);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(155, 47);
			this->button2->TabIndex = 4;
			this->button2->Text = L"��������";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// label1
			// 
			this->label1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(26, 11);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(120, 25);
			this->label1->TabIndex = 5;
			this->label1->Text = L"��������:";
			// 
			// label2
			// 
			this->label2->Anchor = System::Windows::Forms::AnchorStyles::Top;
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(682, 46);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(161, 25);
			this->label2->TabIndex = 6;
			this->label2->Text = L"������ �����:";
			// 
			// comboBox1
			// 
			this->comboBox1->Anchor = System::Windows::Forms::AnchorStyles::Top;
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(570, 74);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(344, 33);
			this->comboBox1->TabIndex = 7;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox1_SelectedIndexChanged);
			// 
			// label3
			// 
			this->label3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(41, 11);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(92, 25);
			this->label3->TabIndex = 11;
			this->label3->Text = L"������:";
			// 
			// button4
			// 
			this->button4->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->button4->Location = System::Drawing::Point(10, 92);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(155, 47);
			this->button4->TabIndex = 10;
			this->button4->Text = L"�������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->button5->Location = System::Drawing::Point(10, 39);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(155, 47);
			this->button5->TabIndex = 9;
			this->button5->Text = L"�������";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->panel1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->panel3);
			this->panel1->Controls->Add(this->panel2);
			this->panel1->Location = System::Drawing::Point(12, 445);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(373, 196);
			this->panel1->TabIndex = 12;
			this->panel1->Visible = false;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(110, 13);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(161, 25);
			this->label4->TabIndex = 15;
			this->label4->Text = L"������ �����";
			// 
			// panel3
			// 
			this->panel3->BackColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->panel3->Controls->Add(this->label3);
			this->panel3->Controls->Add(this->button5);
			this->panel3->Controls->Add(this->button4);
			this->panel3->Location = System::Drawing::Point(198, 41);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(171, 149);
			this->panel3->TabIndex = 14;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->panel2->Controls->Add(this->label1);
			this->panel2->Controls->Add(this->button2);
			this->panel2->Controls->Add(this->button1);
			this->panel2->Location = System::Drawing::Point(3, 41);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(171, 149);
			this->panel2->TabIndex = 13;
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView1->BackgroundColor = System::Drawing::SystemColors::ButtonFace;
			this->dataGridView1->ColumnHeadersHeight = 29;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {
				this->Column1,
					this->Column2
			});
			this->dataGridView1->Cursor = System::Windows::Forms::Cursors::Arrow;
			this->dataGridView1->Location = System::Drawing::Point(417, 159);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 10;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(686, 403);
			this->dataGridView1->TabIndex = 13;
			// 
			// Column1
			// 
			this->Column1->Frozen = true;
			this->Column1->HeaderText = L"�����";
			this->Column1->MinimumWidth = 6;
			this->Column1->Name = L"Column1";
			this->Column1->ReadOnly = true;
			this->Column1->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column1->Width = 125;
			// 
			// Column2
			// 
			this->Column2->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::Fill;
			this->Column2->HeaderText = L"�������";
			this->Column2->MinimumWidth = 388;
			this->Column2->Name = L"Column2";
			this->Column2->ReadOnly = true;
			this->Column2->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			// 
			// label5
			// 
			this->label5->Anchor = System::Windows::Forms::AnchorStyles::Top;
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(708, 131);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(108, 25);
			this->label5->TabIndex = 15;
			this->label5->Text = L"����� ��";
			// 
			// timer1
			// 
			this->timer1->Interval = 300;
			this->timer1->Tick += gcnew System::EventHandler(this, &MyForm::timer1_Tick);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->pictureBox1->Location = System::Drawing::Point(12, 159);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(373, 280);
			this->pictureBox1->TabIndex = 16;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Visible = false;
			// 
			// label6
			// 
			this->label6->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(12, 131);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(0, 25);
			this->label6->TabIndex = 17;
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Checked = true;
			this->checkBox1->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox1->Location = System::Drawing::Point(417, 568);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(266, 29);
			this->checkBox1->TabIndex = 18;
			this->checkBox1->Text = L"�������������� �����";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &MyForm::checkBox1_CheckedChanged);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(12, 25);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->ClientSize = System::Drawing::Size(1115, 653);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->menuStrip1);
			this->Enabled = false;
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->MinimumSize = System::Drawing::Size(971, 600);
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"����";
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &MyForm::MyForm_FormClosed);
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void N13ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine("����� �� �������!");
		file->Close();
		Application::Exit();
	}
private: System::Void N12ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	MessageBox::Show("�� - ���� ������.\n�� - �������������� ������������.\n��� - ������������������� ������.\n���� - ��������� ����������� ������ �� ��������� ������.\n", "�������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
}

private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	this->Visible = false;
	this->Enabled = false;
	dataGridView1->Rows->Clear();
	comboBox1->Text = "";
	auth^ f = gcnew auth();
	f->ShowDialog();
	this->Visible = false;

	if (f->live == true) {
		this->Visible = true;
		this->Enabled = true;
		timer1->Enabled = true;
		

		using namespace System::IO;
		StreamReader^ file = gcnew StreamReader("Camera.chp");
		String^ n;
		n = file->ReadLine();
		for (int i = 0; i < System::Convert::ToInt32(n); i++) {
			String^ s;
			s = file->ReadLine();
			comboBox1->Items->Add(s);
		}
		file->Close();
		delete f;


		StreamReader^ file1 = gcnew StreamReader("automatic.chp");
		n = file1->ReadLine();
		file1->Close();

		if (n == "0") {
			checkBox1->Checked = false;
		}
		else {
			checkBox1->Checked = true;
		}
	}
	else {
		delete f;
		Application::Exit();
	}
	
	pictureBox1->Visible = true;
	pictureBox1->SizeMode = PictureBoxSizeMode::StretchImage;

}


private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e) {
	using namespace System::IO;


	std::ifstream fin("intruder\\1.txt");
	if (fin.is_open()) {
		fin.close();


		StreamReader^ file1 = gcnew StreamReader("intruder\\1.txt");
		String^ n;
		n = file1->ReadLine();

		if (n == "1") {
			String^ d;
			d = file1->ReadLine();
			comboBox1->SelectedIndex = System::Convert::ToInt32(d);




			n = file1->ReadLine();
			file1->Close();
			pictureBox1->Image = System::Drawing::Bitmap::FromFile("intruder\\" + n);
			StreamWriter^ file2 = gcnew StreamWriter("intruder\\1.txt");
			file2->WriteLine("0");
			file2->Close();
			label6->Text = "���������� �������������� ����";


			StreamWriter^ file13 = gcnew StreamWriter(kamera + ".chp", true);
			DateTime now13 = DateTime::Now;
			file13->WriteLine(now13.Hour.ToString() + ":" + now13.Minute.ToString());
			file13->WriteLine(kamera + " - ���������� �������������� ����!");
			file13->Close();



		}
		file1->Close();
	}


	if (kamera != "") {
		

		StreamReader^ file12 = gcnew StreamReader(kamera + ".chp");
		mode = file12->ReadLine();
		int k = 0;
		String^ nn;
		for (int i = 0; (nn = file12->ReadLine()) != nullptr; i++) {
			k++;
			String^ ss;
			ss = file12->ReadLine();
		}
		file12->Close();


		if (k != kamera_n) {
			dataGridView1->Rows->Clear();
			StreamReader^ file = gcnew StreamReader(kamera + ".chp");
			String^ n;
			mode = file->ReadLine();
			kamera_n = 0;
			for (int i = 0; (n = file->ReadLine()) != nullptr; i++) {
				kamera_n++;
				dataGridView1->Rows->Add();
				String^ s;

				if (i != 0) {
					for (int j = kamera_n - 1; j > 0; j--) {
						s = System::Convert::ToString(dataGridView1->Rows[j - 1]->Cells[0]->Value);
						dataGridView1->Rows[j]->Cells[0]->Value = s;
						s = System::Convert::ToString(dataGridView1->Rows[j - 1]->Cells[1]->Value);
						dataGridView1->Rows[j]->Cells[1]->Value = s;
					}

				}

				dataGridView1->Rows[0]->Cells[0]->Value = n;
				s = file->ReadLine();
				dataGridView1->Rows[0]->Cells[1]->Value = s;


			}
			file->Close();
			if (mode == "1") {
				panel2->Visible = false;
				panel3->Visible = true;
			}
			else if (mode == "2") {
				panel2->Visible = true;
				panel3->Visible = false;

			}
			
		}

	}
	
	fin.open("system\\1.txt");
	if (fin.is_open()) {
		fin.close();
		StreamReader^ file4 = gcnew StreamReader("system\\1.txt");
		String^ n2;
		n2 = file4->ReadLine();
		file4->Close();

		if (System::Convert::ToInt32(n2) == sys) {
			N1->Enabled = true;
		}
		else {
			sys = System::Convert::ToInt32(n2);
			N1->Enabled = false;
		}


	}








	
}


private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	if (kamera != comboBox1->Text)
		kamera = comboBox1->Text;
	else 
		return;
	panel1->Visible = true;
	dataGridView1->Rows->Clear();

	using namespace System::IO;
	StreamReader^ file = gcnew StreamReader(kamera + ".chp");
	String^ n;
	mode = file->ReadLine();
	kamera_n = 0;
	for (int i = 0; (n = file->ReadLine()) != nullptr; i++) {
		kamera_n++;
		dataGridView1->Rows->Add();
		String^ s;

		if (i != 0) {
			for (int j = kamera_n - 1; j > 0; j--) {
				s = System::Convert::ToString(dataGridView1->Rows[j - 1]->Cells[0]->Value);
				dataGridView1->Rows[j]->Cells[0]->Value = s;
				s = System::Convert::ToString(dataGridView1->Rows[j - 1]->Cells[1]->Value);
				dataGridView1->Rows[j]->Cells[1]->Value = s;
			}
			
		}
		

		dataGridView1->Rows[0]->Cells[0]->Value = n;
		s = file->ReadLine();
		dataGridView1->Rows[0]->Cells[1]->Value = s;

		
	}
	file->Close();
	if (mode == "1") {
		panel2->Visible = false;
		panel3->Visible = true;
	}
	else if (mode == "2") {
		panel2->Visible = true;
		panel3->Visible = false;

	}
	
	
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (Up == true)
		return;

	if (kamera != "") {
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ����������� � ������!");
		file->Close();
		kamera_n++;
		dataGridView1->Rows->Add();
		dataGridView1->Rows[kamera_n - 1]->Cells[0]->Value = now.Hour.ToString() + ":" + now.Minute.ToString();
		dataGridView1->Rows[kamera_n - 1]->Cells[1]->Value = kamera + " ����������� � ������!";
		Up = true;

		StreamWriter^ file2 = gcnew StreamWriter("barrier.chp");
		file2->WriteLine("1");
		file2->Close();

		checkBox1->Checked = false;
		StreamWriter^ file3 = gcnew StreamWriter("automatic.chp");
		file3->WriteLine("0");
		file3->Close();
	}
	else {
		MessageBox::Show("�������� ������!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);

	}

}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (Up == false)
		return;

	if (kamera != "") {
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ����������� � ������!");
		file->Close();
		kamera_n++;
		dataGridView1->Rows->Add();
		dataGridView1->Rows[kamera_n - 1]->Cells[0]->Value = now.Hour.ToString() + ":" + now.Minute.ToString();
		dataGridView1->Rows[kamera_n - 1]->Cells[1]->Value = kamera + " ����������� � ������!";
		Up = false;

		StreamWriter^ file2 = gcnew StreamWriter("barrier.chp");
		file2->WriteLine("0");
		file2->Close();

		checkBox1->Checked = false;
		StreamWriter^ file3 = gcnew StreamWriter("automatic.chp");
		file3->WriteLine("0");
		file3->Close();


	}
	else {
		MessageBox::Show("�������� ������!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);

	}



}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	if (Up == true)
		return;

	if (kamera != "") {
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ����������� � ������!");
		file->Close();
		kamera_n++;
		dataGridView1->Rows->Add();
		dataGridView1->Rows[kamera_n - 1]->Cells[0]->Value = now.Hour.ToString() + ":" + now.Minute.ToString();
		dataGridView1->Rows[kamera_n - 1]->Cells[1]->Value = kamera + " ����������� � ������!";
		Up = true;


		StreamWriter^ file2 = gcnew StreamWriter("vorota.chp");
		file2->WriteLine("1");
		file2->Close();

		checkBox1->Checked = false;
		StreamWriter^ file3 = gcnew StreamWriter("automatic.chp");
		file3->WriteLine("0");
		file3->Close();

	}
	else {
		MessageBox::Show("�������� ������!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);

	}
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (Up == false)
		return;

	if (kamera != "") {
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ����������� (� ������)!");
		file->Close();
		kamera_n++;
		dataGridView1->Rows->Add();
		dataGridView1->Rows[kamera_n - 1]->Cells[0]->Value = now.Hour.ToString() + ":" + now.Minute.ToString();
		dataGridView1->Rows[kamera_n - 1]->Cells[1]->Value = kamera + " ����������� (� ������)!";
		Up = false;

		StreamWriter^ file2 = gcnew StreamWriter("vorota.chp");
		file2->WriteLine("0");
		file2->Close();

		checkBox1->Checked = false;
		StreamWriter^ file3 = gcnew StreamWriter("automatic.chp");
		file3->WriteLine("0");
		file3->Close();
	}
	else {
		MessageBox::Show("�������� ������!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);

	}
}
private: System::Void MyForm_FormClosed(System::Object^ sender, System::Windows::Forms::FormClosedEventArgs^ e) {
	using namespace System::IO;
	StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
	DateTime now = DateTime::Now;
	file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString() + ":" + now.Second.ToString() + " " + now.Day.ToString() + "." + now.Month.ToString() + "." + now.Year.ToString() + " - ����� �� �������!");
	file->Close();
}
private: System::Void N1_Click(System::Object^ sender, System::EventArgs^ e) {
	system("start start_prus.exe");
}
private: System::Void N2_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Visible = false;

	bdman^ f = gcnew bdman();
	f->ShowDialog();
	if (f->live == false) {
		delete f;
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString() + ":" + now.Second.ToString() + " " + now.Day.ToString() + "." + now.Month.ToString() + "." + now.Year.ToString() + " - ����� �� �������!");
		file->Close();
		Application::Exit();

	}
	delete f;
	this->Visible = true;
}
private: System::Void N3_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Visible = false;
	bdnsd^ f = gcnew bdnsd();
	f->ShowDialog();
	if (f->live == false) {
		delete f;
		using namespace System::IO;
		StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString() + ":" + now.Second.ToString() + " " + now.Day.ToString() + "." + now.Month.ToString() + "." + now.Year.ToString() + " - ����� �� �������!");
		file->Close();
		Application::Exit();

	}
	delete f;
	this->Visible = true;
}
private: System::Void checkBox1_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	using namespace System::IO;
	StreamWriter^ file1 = gcnew StreamWriter("automatic.chp");
	if (checkBox1->Checked == true) {
		file1->WriteLine("1");
		file1->Close();

		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ���������(-�) � �������������� �����!");
		file->Close();
	}
	else {
		file1->WriteLine("0");
		file1->Close();
		StreamWriter^ file = gcnew StreamWriter(kamera + ".chp", true);
		DateTime now = DateTime::Now;
		file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString());
		file->WriteLine(kamera + " ���������(-�) � ������ �����!");
		file->Close();
	}
	
	


}
};
}
