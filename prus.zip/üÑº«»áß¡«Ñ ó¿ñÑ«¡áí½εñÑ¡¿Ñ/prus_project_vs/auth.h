#pragma once

namespace prus {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� auth
	/// </summary>
	public ref class auth : public System::Windows::Forms::Form
	{
	public:
		bool live = false;
		auth(void)
		{
			live = false;
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~auth()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;

	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::CheckBox^ checkBox1;
	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(auth::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button1->Location = System::Drawing::Point(242, 257);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(143, 58);
			this->button1->TabIndex = 0;
			this->button1->Text = L"�����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &auth::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox1->Location = System::Drawing::Point(184, 60);
			this->textBox1->MaxLength = 30;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(260, 30);
			this->textBox1->TabIndex = 2;
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox2->Location = System::Drawing::Point(184, 139);
			this->textBox2->MaxLength = 30;
			this->textBox2->Name = L"textBox2";
			this->textBox2->PasswordChar = '*';
			this->textBox2->Size = System::Drawing::Size(260, 30);
			this->textBox2->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(110, 63);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(68, 25);
			this->label1->TabIndex = 4;
			this->label1->Text = L"�����";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(98, 142);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(80, 25);
			this->label2->TabIndex = 5;
			this->label2->Text = L"������";
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(450, 147);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(92, 20);
			this->checkBox1->TabIndex = 6;
			this->checkBox1->Text = L"��������";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &auth::checkBox1_CheckedChanged);
			// 
			// auth
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ButtonShadow;
			this->ClientSize = System::Drawing::Size(610, 327);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"auth";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"����";
			this->TopMost = true;
			this->Load += gcnew System::EventHandler(this, &auth::auth_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		if (textBox1->Text == "" || textBox1->Text == "") {
			live = false;
			MessageBox::Show("������� ����� ��� ������!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
			
			return;
		}
			
		String^ login;
		String^ pass;
		if (textBox1->Text->Length < 30 && textBox2->Text->Length < 30) {
			login = textBox1->Text;
			pass = textBox2->Text;
		}
		else {
			textBox1->Text = "";
			textBox2->Text = "";
			this->Visible = false;
			return;
		}

		


		using namespace System::IO;
		StreamReader^ file = gcnew StreamReader("psw.chp");
		String^ l;
		String^ p;
		l = file->ReadLine();
		p = file->ReadLine();
		file->Close();


		


		if (p == pass && l == login) {
			live = true;
			this->Visible = false;
			using namespace System::IO;
			StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
			DateTime now = DateTime::Now;
			file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString() + ":" + now.Second.ToString() + " " + now.Day.ToString() + "." + now.Month.ToString() + "." + now.Year.ToString() + " - ���� � �������!");
			file->Close();
		}
		else {
			using namespace System::IO;
			StreamWriter^ file = gcnew StreamWriter("NSD.chp", true);
			DateTime now = DateTime::Now;
			file->WriteLine(now.Hour.ToString() + ":" + now.Minute.ToString() + ":" + now.Second.ToString() + " " + now.Day.ToString() + "." + now.Month.ToString() + "." + now.Year.ToString() + " - ��������� ������� �����!");
			file->Close();
			textBox1->Text = "";
			textBox2->Text = "";
			MessageBox::Show("���������� ��� ���!", "��������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);

		}
		
	}
	private: System::Void auth_Load(System::Object^ sender, System::EventArgs^ e) {
		live = false;
		button1->Visible = false;
		textBox1->Text = "";
		textBox2->Text = "";

		button1->Visible = true;
		this->Text = L"����";
		

	}
	private: System::Void checkBox1_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		if (checkBox1->Checked == true) {
			textBox2->PasswordChar = 0;
		}
		else {
			textBox2->PasswordChar = '*';
		}
	}
};
}
