﻿// simulate.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <windows.h>
#include <thread>
#include <string>

using namespace std;

int nsd = 0;
void photo() {
    system("dir BD_BAD /b > temp.chp");
    while (true) {
        string s;
        s.clear();
        ifstream fin("temp.chp");

        int i = 0;
        while (getline(fin, s)) {
            int k = 0;
            i++;
            int kamera = rand() % i;
            do {
                ifstream fin1("PRUS\\intruder\\1.txt");
                fin1 >> k;
                fin1.close();
                Sleep(500);

            } while (k != 0);
            system("det_image.exe");
            ifstream fin32("Dostyp\\Journal.txt");
            if (fin32.is_open()) {
                fin32 >> nsd;
                fin32.close();
            }
            else {
                nsd = 0;
            }
            

            if (k == 0 && nsd != 0) {
                cout << "Отправка фото - " << s.c_str() << endl;
                system("del /q PRUS\\intruder");
                string com;
                com = "BD_BAD\\" + s;
                
                std::ifstream fin2(com.c_str(), std::ios_base::binary | std::ios_base::ate);
                if (!fin2.is_open()) {
                    continue;
                }
                int r = fin2.tellg();
                char* str = new char[r + 1];
                fin2.seekg(0, std::ios_base::beg);
                fin2.read(str, r);
                fin2.close();
                str[r] = '\0';

                com = "PRUS\\intruder\\" + s;
                ofstream fout(com.c_str(), std::ios_base::binary | std::ios_base::ate);
                fout.write(str, r);
                fout.close();


                ofstream fout1("PRUS\\intruder\\1.txt");
                fout1 << 1 << endl << kamera << endl << s.c_str();
                fout1.close();

          



            }
            Sleep(rand() % 2000 + 1000);
        }
        fin.close();
        Sleep(2000);
        
    }




}
void system_time() {
    int count = 0;
    
    while (true) {
        if (count > 10000000) {
            count = 0;
        }else
            count++;
        ofstream fout("PRUS\\system\\1.txt");
        fout << count;
        fout.close();

        Sleep(150);
    }

}

int main()
{
    system("chcp 1251");
    cout << "Это симуляция работы системы PRUS" << endl;
    
    std::thread t1(system_time);
    t1.detach();

    std::thread t2(photo);
    t2.detach();

    while (true) {
        
        
        

        Sleep(400);
    }


    return 0;
}

